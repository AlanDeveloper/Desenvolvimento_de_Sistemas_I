<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Usuario extends CI_Controller {

		public function __construct() {
			parent::__construct();

			$this->load->model('User_Model', 'user');
		}

		public function register() {
			if($_SERVER['REQUEST_METHOD'] === 'POST') {
				$data = array(
					'name' => $_POST['name'],
					'email' => $_POST['email'],
					'password' => $_POST['password'],
					'address' => $_POST['address'],
					'city' => $_POST['city'],
					'state' => $_POST['state'],
					'number' => $_POST['number']
				);

				$_SESSION['username'] = $data['name'];
				$_SESSION['admin'] = False;
				$this->user->register($data);
				
				header('Location: /home');
			} else {
				$this->load->view('usuario/form');
			}
		}

		public function login() {
			if($_SERVER['REQUEST_METHOD'] === 'POST') {
				$r = $this->user->login($_POST['email'], $_POST['password']);
				if(count($r) === 1) {
					$_SESSION['username'] = $r[0]->name;
					$_SESSION['admin'] = $r[0]->admin;
					header('Location: /home');
				} else {
					header('Location: /usuario/login');
				}

			} else {
				$this->load->view('usuario/login');
			}
		}

		public function exit() {
			unset($_SESSION['username']);
			unset($_SESSION['admin']);

			header('Location: /home');
		}

		public function list() {
			$data['data'] = $this->user->list();
			$this->load->view('usuario/list', $data);
		}

		public function delete() {
			$this->user->delete($_GET['code']);

			header('Location: /home');
		}

		public function search() {
			$data['data'] = $this->user->search();
			$this->load->view('usuario/search', $data);
		}

		public function update() {
			if($_SERVER['REQUEST_METHOD'] === 'POST') {
				$data = array(
					'code' => $_GET['code'],
					'name' => $_POST['name'],
					'email' => $_POST['email'],
					'password' => $_POST['password'],
					'address' => $_POST['address'],
					'city' => $_POST['city'],
					'state' => $_POST['state'],
					'number' => $_POST['number']
				);

				$this->user->update($data);
				header('Location: /home');
			} else {
				$data['data'] = $this->user->search($_GET['code']);
				$this->load->view('usuario/update', $data);
			}
		}
		
		public function buy() {
			$data['data'] = $this->user->buy($_GET['code']);

			$this->load->view('usuario/buy', $data);
		}

		public function message() {
			if($_SERVER['REQUEST_METHOD'] === 'POST') {

				$recip = $this->user->list();
				$array = [];
				for ($i=0; $i < count($recip); $i++) { 
					array_push($array, $recip[$i]->email);
				}

				$this->email->from("teste.ds1.teste@gmail.com", $_POST['title']);
				$this->email->subject($_POST['subtitle']);
				$this->email->to($array); 
				$this->email->message($_POST['body']);
				$this->email->send();

				header('Location: /home');
			} else {
				$this->load->view('usuario/message');
			}
		}

		public function pdf(){
			$data = $this->user->list();

			require_once("application/views/fpdf/fpdf.php");

			$pdf= new FPDF("P","pt","A4");
			// utf8_decode($pdf);

			$pdf->AddPage();
			$pdf->SetFont('arial','B',12);
			$txt = utf8_decode('Nome | Email | Endereço | Número');
			$pdf->Cell(0,5, $txt,0,1,'C');
			$pdf->Ln(30);
			for ($i=0; $i < count($data); $i++) { 
				$pdf->SetFont('arial','',12);
				$pdf->Cell(0,5, 
					utf8_decode($data[$i]->name) . ' | ' . 
					utf8_decode($data[$i]->email) . ' | ' .
					utf8_decode($data[$i]->address) . ' | ' .
					utf8_decode($data[$i]->number)
					,0,1,'C');
				$pdf->Ln(20);
			}
			$pdf->Output();
		}
	}
?>
