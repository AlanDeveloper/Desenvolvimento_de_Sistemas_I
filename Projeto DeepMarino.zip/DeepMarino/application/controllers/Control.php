<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Control extends CI_Controller {

		public function __construct() {
			parent::__construct();

			$this->load->model('Produto_Model', 'produto');
		}
		
		public function index() {
			$data['data'] = $this->produto->list();
			$this->load->view('index', $data);
		}
	}
?>