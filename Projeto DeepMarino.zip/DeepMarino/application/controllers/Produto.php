<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Produto extends CI_Controller {

		public function __construct() {
			parent::__construct();

			$this->load->model('Produto_Model', 'produto');
		}

		public function register() {
			if($_SERVER['REQUEST_METHOD'] === 'POST') {
				$upload = $this->upload();
				$data = array(
					'name' => $_POST['name'],
					'value' => $_POST['value'],
					'amount' => $_POST['amount'],
					'descrip' => $_POST['descrip'],
					'weight' => $_POST['weight'],
					'keywords' => $_POST['keywords'],
					'path' => $upload
				);

				$this->produto->register($data);

				header('Location: /home');
			} else {
				$this->load->view('produto/form');
			}
		}

		public function upload() {
			$upload = '';
			$uploaddir = 'application/views/uploads/';
			$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);
			$ext = explode('.', basename($_FILES['userfile']['name']))[1]; 

			if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
				$date = date('Y-m-d H:i');
				$date = str_replace(' ', '-', $date);
				$upload = $uploaddir.$date.'.'.$ext;
				rename($uploadfile, $upload);
			}

			return $upload;
		}

		public function list() {
			$data['data'] = $this->produto->list();
			$this->load->view('produto/list', $data);
		}

		public function delete() {
			$this->produto->delete($_GET['code']);

			header('Location: /home');
		}

		public function search() {
			$data['data'] = $this->produto->search();
			$this->load->view('produto/search', $data);
		}

		public function update() {
			if($_SERVER['REQUEST_METHOD'] === 'POST') {
				$data = array(
					'code' => $_GET['code'],
					'name' => $_POST['name'],
					'value' => $_POST['value'],
					'amount' => $_POST['amount'],
					'descrip' => $_POST['descrip'],
					'weight' => $_POST['weight'],
					'keywords' => $_POST['keywords'],
				);

				$this->produto->update($data);
				header('Location: /home');
			} else {
				$data['data'] = $this->produto->search($_GET['code']);
				$this->load->view('produto/update', $data);
			}
		}

		public function view() {
			$data['data'] = $this->produto->search($_GET['code']);
			$this->load->view('produto/view', $data);
		}

		public function pdf(){
			$data = $this->produto->list();

			require_once("application/views/fpdf/fpdf.php");

			$pdf= new FPDF("P","pt","A4");

			$pdf->AddPage();
			$pdf->SetFont('arial','B',12);
			$txt = utf8_decode('Nome | Valor | Quantidade | Peso');
			$pdf->Cell(0,5, $txt,0,1,'C');
			$pdf->Ln(30);
			for ($i=0; $i < count($data); $i++) { 
				$pdf->SetFont('arial','',12);
				$pdf->Cell(0,5, 
					utf8_decode($data[$i]->name) . ' | ' . 
					utf8_decode($data[$i]->value) . ' | ' .
					utf8_decode($data[$i]->amount) . ' | ' .
					utf8_decode($data[$i]->weight)
					,0,1,'C');
				$pdf->Ln(20);
			}
			$pdf->Output();
		}
	}
?>
