<?php
    $config['smtp_host'] = 'ssl://smtp.gmail.com';
    $config['smtp_port'] = 465;
    $config['smtp_user'] = 'teste.ds1.teste@gmail.com';
    $config['smtp_pass'] = 'teste.ds1';
    $config['protocol']  = 'smtp';
    $config['validate']  = TRUE;
    $config['mailtype']  = 'html';
    $config['charset']   = 'utf-8';
    $config['newline']   = "\r\n";
?>