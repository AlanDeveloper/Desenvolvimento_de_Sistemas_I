<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="./application/views/style/header.css">
	<link rel="stylesheet" href="./application/views/style/home.css">
	<title>DeepMarino</title>
</head>
<body>
	<?php include 'application/views/header.php'; ?>
	<main>
		<?php
			for ($i=0; $i < count($data); $i++) {
				$list = '';
				$list .= '<img src="'.$data[$i]->path.'" height="150px" width="200px" alt="img">';
				$list .= '<p class="title">'. $data[$i]->name .'</p>';
				$list .= '<p class="value"> R$ '. $data[$i]->value .',00</p>';
				$list .= '<span class="link"><a href="produto/view?code='.$data[$i]->code.'">Ver produto</a></span>';

				echo '<div class="card">'. $list .'</div>';
			}
		?>
	</main>
</body>
</html>