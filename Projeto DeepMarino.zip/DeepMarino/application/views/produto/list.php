<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="../application/views/style/header.css">
	<link rel="stylesheet" href="../application/views/style/list.css">
	<title>DeepMarino</title>
</head>
<body>
	<?php include 'application/views/header.php'; ?>
	<main>
		<span class="link">
			<a href="/produto/pdf">Gerar PDF</a>
		</span>
		<form action="/produto/search" method="post">
			<input type="text" name="name" placeholder="O que você deseja?">
			<input type="submit" value="Procurar">
		</form>
		<table>
			<tr>
				<th>Nome</th>
				<th>Preço</th>
				<th>Quantidade</th>
				<th>Peso</th>
			</tr>
			<?php
				for ($i=0; $i < count($data); $i++) {
					$list = '';
					$list .= '<td>'. $data[$i]->name .'</td>';
					$list .= '<td>'. $data[$i]->value .'</td>';
					$list .= '<td>'. $data[$i]->amount .'</td>';
					$list .= '<td>'. $data[$i]->weight .'</td>';
					$list .= '<td><a href="/produto/view?code='.$data[$i]->code.'">Ver produto</a></td>';
					if(isset($_SESSION['username'])) {
						if($_SESSION['admin'] == True) {
							$list .= '<td><a href="/produto/update?code='.$data[$i]->code.'">Alterar Produto</a></td>';
							$list .= '<td><a href="/produto/delete?code='.$data[$i]->code.'">Deletar Produto</a></td>';
						}
					}
					
					echo '<tr>'. $list .'</tr>';
				}
			?>
		</table>
	</main>
</body>
</html>

