<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="../application/views/style/header.css">
	<link rel="stylesheet" href="../application/views/style/form.css">
	<title>DeepMarino</title>
</head>
<body>
	<?php include 'application/views/header.php'; ?>
	<main>
		<form action="/produto/register" method="post" enctype="multipart/form-data">
			<input type="text" name="name" placeholder="Nome do produto">
			<input type="text" name="keywords" placeholder="Palavras chave">
			<input type="number" name="weight" placeholder="Peso">
			<input type="number" name="value" placeholder="Valor do produto">
			<input type="number" name="amount" placeholder="Quantidade">
			<input type="hidden" name="MAX_FILE_SIZE" value="30000" />
			<input name="userfile" type="file"/>
			<textarea name="descrip" cols="30" rows="10" placeholder="Descrição"></textarea>
			<input type="submit" value="Registrar">
		</form>
	</main>
</body>
</html>
