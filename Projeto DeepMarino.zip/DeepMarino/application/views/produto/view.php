<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../application/views/style/header.css">
    <link rel="stylesheet" href="../application/views/style/view.css">
    <title>DeepMarino</title>
</head>
<body>
    <?php include 'application/views/header.php'; ?>

    <main>
        <?php
            for ($i=0; $i < count($data); $i++) {
                $list = '';
                $div = '';

                $list .= '<tr><td>Nome:</td><td>'. $data[$i]->name .'</td></tr>';
                $list .= '<tr><td>Descrição:</td><td>'. $data[$i]->descrip .'</td></tr>';
                $list .= '<tr><td>Preço:</td><td>'. $data[$i]->value .'</td></tr>';
                $list .= '<tr><td>Quantidade:</td><td>'. $data[$i]->amount .'</td></tr>';
                $list .= '<tr><td>Peso:</td><td>'. $data[$i]->weight .'</td></tr>';

                $div .= '<img src="../'.$data[$i]->path.'" alt="img" width="300px" height="250px">';
                $div .= '<h2>'.$data[$i]->name.'</h2>';
                $div .= '<span><a href="#">Adicionar ao carrinho</a></span>';
                $div .= '<span><a href="#">Comprar</a></span>';
            }
        ?>
        <div><?php echo $div; ?></div>
        <table><?php echo $list; ?></table>
    </main>
</body>
</html>