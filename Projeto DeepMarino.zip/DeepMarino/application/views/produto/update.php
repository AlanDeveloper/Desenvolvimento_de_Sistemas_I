<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="../application/views/style/header.css">
	<link rel="stylesheet" href="../application/views/style/form.css">
	<style>
		input[type="submit"] {
			margin-top: 12px;
		}
	</style>
	<title>DeepMarino</title>
</head>
<body>
	<?php include 'application/views/header.php'; ?>
	<main>
		<?php
			for ($i=0; $i < count($data); $i++) {
				echo 
				'<form action="/produto/update?code='.$data[$i]->code.'" method="post">
					<input type="text" name="name" value="'.$data[$i]->name.'">
					<input type="text" name="descrip" value="'.$data[$i]->descrip.'">
					<input type="number" name="value" value="'.$data[$i]->value.'">
					<input type="number" name="amount" value="'.$data[$i]->amount.'">
					<input type="number" name="weight" value="'.$data[$i]->weight.'">
					<input type="text" name="keywords" value="'.$data[$i]->keywords.'">
					<input type="submit" value="Enviar">
				</form>';
			}
		?>
	</main>
</body>
</html>

