
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="../application/views/style/header.css">
	<link rel="stylesheet" href="../application/views/style/form.css">
	<style>
		main {
			text-align: center;
		}
		input[type="submit"] {
			position: absolute;
			margin-top: 10px;
		}
	</style>
	<title>DeepMarino</title>
</head>
<body>
	<?php include 'application/views/header.php'; ?>
	<main>
		<form action="/usuario/login" method="post">
			<input type="email" name="email" placeholder="Digite seu email">
			<input type="password" name="password" placeholder="Digite sua senha">
			<input type="submit" value="Enviar">
		</form>
	</main>
</body>
</html>
