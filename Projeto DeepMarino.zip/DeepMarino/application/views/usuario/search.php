<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="../application/views/style/header.css">
	<link rel="stylesheet" href="../application/views/style/list.css">
	<title>DeepMarino</title>
</head>
<body>
	<?php include 'application/views/header.php'; ?>
	<main>
		<form action="/produto/search" method="post">
			<input type="text" name="name" placeholder="O que você deseja?">
			<input type="submit" value="Procurar">
		</form>
		<table>
			<tr>
				<th>Nome</th>
				<th>Email</th>
				<th>Estado</th>
				<th>Cidade</th>
				<th>Rua</th>
				<th>Número da casa</th>
			</tr>
			<?php
				for ($i=0; $i < count($data); $i++) {
					$list = '';
					$list .= '<td>'. $data[$i]->name .'</td>';
					$list .= '<td>'. $data[$i]->email .'</td>';
					$list .= '<td>'. $data[$i]->state .'</td>';
					$list .= '<td>'. $data[$i]->city .'</td>';
					$list .= '<td>'. $data[$i]->address .'</td>';
					$list .= '<td>'. $data[$i]->number .'</td>';
					$list .= '<td><a href="/usuario/buy?code='.$data[$i]->code.'">Lista de compras</a></td>';
					$list .= '<td><a href="/usuario/update?code='.$data[$i]->code.'">Alterar usuario</a></td>';
					$list .= '<td><a href="/usuario/delete?code='.$data[$i]->code.'">Deletar usuario</a></td>';
					
					echo '<tr>'. $list .'</tr>';
				}
			?>
		</table>
	</main>
</body>
</html>

