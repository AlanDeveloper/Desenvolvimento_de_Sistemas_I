<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../application/views/style/header.css">
	<title>DeepMarino</title>
</head>
<body>
    <?php include 'application/views/header.php'; ?>
    <main>
        <table>
            <?php
                for ($i=0; $i < count($data); $i++) {
                    $list = '';
                    $list .= '<td>'. $data[$i]->name .'</td>';
                    $list .= '<td>'. $data[$i]->value .'</td>';
                    $list .= '<td>'. $data[$i]->amount .'</td>';
                    
                    echo '<tr>'. $list .'</tr>';
                }

                if(count($data) === 0) {
                    echo '<tr><td>Nenhuma compra realizada</td></tr>';
                }
            ?>
        </table>
    </main>
</body>
</html>

