<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="../application/views/style/header.css">
	<link rel="stylesheet" href="../application/views/style/form.css">
	<style>
		input[type="submit"] {
			margin-top: 12px;
		}
	</style>
	<title>DeepMarino</title>
</head>
<body>
	<?php include 'application/views/header.php'; ?>
	<main>
		<?php
			for ($i=0; $i < count($data); $i++) {
				echo 
				'<form action="/usuario/update?code='.$data[$i]->code.'" method="post">
					<input type="text" name="name" value="'.$data[$i]->name.'">
					<input type="email" name="email" value="'.$data[$i]->email.'">
					<input type="password" name="password" value="'.$data[$i]->password.'">
					<input type="text" name="state" value="'.$data[$i]->state.'">
					<input type="text" name="city" value="'.$data[$i]->city.'">
					<input type="text" name="address" value="'.$data[$i]->address.'">
					<input type="number" name="number" value="'.$data[$i]->number.'">
					<input type="submit" value="Enviar">
				</form>';
			}
		?>
	</main>
</body>
</html>

