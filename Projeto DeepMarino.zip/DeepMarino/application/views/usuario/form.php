
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="../application/views/style/header.css">
	<link rel="stylesheet" href="../application/views/style/form.css">
	<style>
		input[type="submit"] {
			position: absolute;
			margin-top: 10px;
		}
	</style>
	<title>DeepMarino</title>
</head>
<body>
	<?php include 'application/views/header.php'; ?>
	<main>
		<form action="/usuario/register" method="post">
			<input type="text" name="name" placeholder="Digite seu nome">
			<?php 
				echo '<input type="email" name="email" placeholder="Digite seu email">'; 
			?>
			<input type="text" name="state" placeholder="Digite seu estado">
			<input type="text" name="city" placeholder="Digite sua cidade">
			<input type="text" name="address" placeholder="Digite seu endereço">
			<input type="number" name="number" placeholder="Digite o número da casa">
			<input type="password" name="password" placeholder="Digite sua senha">
			<input type="submit" value="Enviar">
		</form>
	</main>
</body>
</html>
