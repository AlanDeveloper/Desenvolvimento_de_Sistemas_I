<?php
    $list = '';
    
    if(isset($_SESSION['username'])) {
        if($_SESSION['admin'] == True) {
            $list = 
                '<li><a href="/produto/register">Cadastrar Produtos</a></li>
                 <li><a href="/usuario/list">Listar Usuários</a></li>';
        }

        $aside = '<aside><a href="/usuario/exit">Sair</a></aside>';
    } else {
        $aside = '<aside><a href="/usuario/login">Entrar</a><a href="/usuario/register">Registrar</a></aside>';
    }
?>
<header>
    <nav>
        <ul>
            <li><a href="/home">Home</a></li>
            <li><a href="/produto/list">Listar Produtos</a></li>
            <?php echo $list; ?>
        </ul>
    </nav>
    <?php echo $aside; ?>
</header>
