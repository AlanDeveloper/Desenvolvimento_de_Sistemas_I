<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Produto_Model extends CI_Model {

		public function register($data) {
			$this->db->insert('produto', $data);
		}
		public function list() {
			return $this->db->get('produto')->result();
		}
		public function delete($code) {
			$this->db->delete('produto', array('code' => $code));
		}
		public function search($code = -1) {
			if($code === -1) {
				$query = 'SELECT * FROM produto WHERE keywords like "%'.$_POST['name'].'%"';
				$result = $this->db->query($query)->result();
			} else {
				$result = $this->db->get_where('produto', array('code' => $code))->result();
			}
			return $result;
		}
		public function update($data) {
			echo $data['code'];
			$this->db->set('name', $data['name']);
			$this->db->set('descrip', $data['descrip']);
			$this->db->set('value', $data['value']);
			$this->db->set('amount', $data['amount']);
			$this->db->set('weight', $data['weight']);
			$this->db->set('keywords', $data['keywords']);
			$this->db->where('code', $data['code']);

			$this->db->update('produto');
		}
	}
?>
