<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class User_Model extends CI_Model {

		public function register($data) {
			$this->db->insert('user', $data);
		}
		public function login($email, $password) {
			return $this->db->get_where('user', array('email' => $email, 'password' => $password))->result();
		}
		public function list() {
			return $this->db->get('user')->result();
		}
		public function delete($code) {
			$this->db->delete('user', array('code' => $code));
		}
		public function search($code = -1) {
			if($code === -1) {
				$query = 'SELECT * FROM user WHERE name like "%'.$_POST['name'].'%"';
				$result = $this->db->query($query)->result();
			} else {
				$result = $this->db->get_where('user', array('code' => $code))->result();
			}
			return $result;
		}
		public function update($data) {
			$this->db->set('name', $data['name']);
			$this->db->set('email', $data['email']);
			$this->db->set('password', $data['password']);
			$this->db->set('state', $data['state']);
			$this->db->set('city', $data['city']);
			$this->db->set('address', $data['address']);
			$this->db->set('number', $data['number']);
			$this->db->where('code', $data['code']);

			$this->db->update('user');
		}

		public function buy($code) {
			return$this->db->get_where('compra', array('codeUS' => $code))->result();
		}
	}
?>
