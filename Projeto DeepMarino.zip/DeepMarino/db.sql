CREATE DATABASE `ds1`;

CREATE TABLE `user` (
	`code` INT NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(100) NOT NULL,
	`email` VARCHAR(200) NOT NULL,
	`password` VARCHAR(100) NOT NULL,
	`address` varchar(200) NOT NULL,
	`number` int NOT NULL,
	`city` varchar(200) NOT NULL,
	`state` varchar(200) NOT NULL,
	`admin` boolean DEFAULT false,
	CONSTRAINT `userpk` PRIMARY KEY (`code`)
);
CREATE TABLE `produto` (
	`code` INT NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(100) NOT NULL,
	`descrip` varchar(1000) NOT NULL,
	`value` INT NOT NULL,
	`amount` INT DEFAULT 0,
	`weight` INT NOT NULL,
	`keywords` varchar(500) NOT NULL,
	`path` varchar(200) NOT NULL,
	CONSTRAINT `produtopk` PRIMARY KEY (`code`)
);
CREATE TABLE `compra`(
    `code` INT NOT NULL AUTO_INCREMENT,
    `codeUS` INT,
    `name` VARCHAR(100) NOT NULL,
    `value` INT NOT NULL,
    `amount` INT NOT NULL,
    CONSTRAINT `comprapk` PRIMARY KEY(`code`),
    CONSTRAINT `comprafk` FOREIGN KEY(`codeUS`) REFERENCES `user`(`code`) ON UPDATE CASCADE ON DELETE CASCADE
);
CREATE TABLE `car`(
    `usercode` INT NOT NULL,
    `productcode` INT NOT NULL,
    `amount` INT DEFAULT 1,
    CONSTRAINT `carpk` PRIMARY KEY(`usercode`, `productcode`),
    CONSTRAINT `caruserfk` FOREIGN KEY(`usercode`) REFERENCES `user`(`code`) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT `carproductfk` FOREIGN KEY(`productcode`) REFERENCES `produto`(`code`) ON UPDATE CASCADE ON DELETE CASCADE
);

INSERT INTO `user`(`name`, `email`, `password`, `address`, `number`, `city`, `state`, `admin`) VALUES ("admin", "admin@gmail.com", "admin", "rua admin", 123, "cidadedoadmin", "estadodoadmin", True);