CREATE DATABASE "work";

CREATE TABLE `HouseSale`(
    `cod` SERIAL,
    `codres` int NOT NULL,
    `desc` varchar(1000) NOT NULL,
    `pic` varchar(1000),
    `oper` boolean NOT NULL,
    `ngbor` varchar(500) NOT NULL,
    `price` float NOT NULL,
    `aloc` int NOT NULL,
    CONSTRAINT `housesalePK` PRIMARY KEY (`cod`)
);

CREATE TABLE `user`(
    `cod` serial,
	`login` varchar(100) NOT NULL,
    `password` varchar(1000) NOT NULL,
    `name` varchar(200) NOT NULL,
    `admin` boolean NOT NULL,
	CONSTRAINT `userpk` PRIMARY KEY (`cod`)
);

INSERT INTO `user` (`login`, `password`, `name`, `admin`) VALUES ('root', '123', 'root linux', 1);

INSERT INTO `HouseSale`(`codres` ,`desc`, `pic`, `oper`, `ngbor`, `price`, `aloc`) VALUES (11 ,"Alan e narigudo", "www.com.br", 0, "Pais dos Nariz Grande", 10, 2);
'UPDATE "HouseSale" SET desc = '.$house->getDesc().', pic = '.$house->getPic().', oper = '.$house->getOper().', ngbor = '.$house->getNgbor().', price = '.$house->getPrice().', aloc = '.$house->getAloc().' WHERE cod = '.$house->getCod;
