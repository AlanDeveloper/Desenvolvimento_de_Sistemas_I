<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('HouseSale','hsale');
		$this->load->model('User', 'user');
		$this->nonadm_pages = array('home', 'listar', 'login');
		$this->nonadm_functions = array('loggout', 'pdf', 'listar');
	}	

	public function view($page = 'home'){
		if($this->session->userdata('logged_in') == null && $page != 'login' && $page != 'register') {
			$page = 'login';
		}
		if ($this->session->userdata('logged_in') != null) {
			if (!$_SESSION['admin']) {
				$permision = False;
				foreach ($this->nonadm_pages as $opt) {
					if ($page == $opt) {
						$permision = True;
					}
				}
				foreach ($this->nonadm_functions as $opt) {
					if ($page == 'Pages/'.$opt) {
						$permision = True;
					}
				}
				if (!$permision) {
					header('Location: /');
				}
			}
			$data['admin'] = $_SESSION['admin'];
		}
		$data['sess'] = $this->session->userdata('logged_in');
		$data['title'] = ucfirst($page);
		$data['assets'] = base_url().'/application/assets/';
		$this->load->view('template/header.php', $data);
		$this->load->view('page/'.$page.'.php', $data);
		$this->load->view('template/footer.php', $data);
	}

	public function loggout() {
		$this->session->set_userdata(array('logged_in' => False, 'name' => ''));
		unset($_SESSION['admin']);
		header('Location: /');
	}
	public function login() {
		$res = $this->user->login(
			array(
				'username' => $this->input->post('username'),
				'password' => $this->input->post('password'))
		);
		if ($res[0]) {
			$this->session->set_userdata(array('logged_in' => $res[0], 'name' => $this->input->post('username')));
			$this->session->set_userdata(array('admin' => $res[1]));
		} else {
			$this->session->set_flashdata('error', '<h2>Dados incorretos<h2>');
		}
		header('Location: /');
	}

	public function register() {
		$this->user->signin(
			array(
				'login' => $this->input->post('username'),
				'name' => $this->input->post('name'),
				'password' => $this->input->post('password')
			)
		);
		header('Location: /');
	}

	public function pdf(){
		# http://www.fpdf.org/
		require_once('application/assets/fpdf/fpdf.php');
		$fil = array();
		$list = $this->hsale->list($fil);
		$pdf= new FPDF("L","pt","A4");
		$pdf->AddPage();
		$pdf->SetFont('arial','B',12);
		foreach ($list as $item) {
			$pdf->Cell(0,5,"Cod: ".$item[0],0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"CodRes: ".$item[1],0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"Descricao: ".$item[2],0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"Operacao: ".$item[3],0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"Bairro: ".$item[4],0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"Preço: ".$item[5],0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"Alocacao: ".$item[6],0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"____________",0,1,'L');
			$pdf->Ln(20);
		}
		$pdf->Output();
	}

	public function inserir() {
		if ($this->input->post('oper') == 'al') {
			$oper = 0;
		} else { $oper = 1; }
		$data = array(
			'codres' => $this->input->post('codres'),
			'desc' => $this->input->post('desc'),
			'pic' => 'application/assets/image/'.$_FILES["img"]["name"],
			'oper' => $oper,
			'ngbor' => $this->input->post('ngbor'),
			'price' => $this->input->post('price'),
			'aloc' => $this->input->post('aloc')
		);
		$this->hsale->add($data);
		header('Location: /');
	}
	public function deletar() {
		$res = $this->hsale->del($this->input->post('codDel'));
		if (!$res) {
			$this->session->set_flashdata('error', '<h2>O codigo digitado não existe<h2>');
		}
		header('Location: /');
	}
	public function listar(){
		$fil = array();
		if ($this->input->post('ngbor') != Null) {
			$fil["ngbor"] = $this->input->post('ngbor');
		}
		if ($this->input->post('aloc') != Null) {
			$fil["aloc"] = $this->input->post('aloc');
		}
		if ($this->input->post('oper') != "sl") {
			$fil["oper"] = $this->input->post('oper');
		}
		$data['list'] = $this->hsale->list($fil);
		if (sizeof($data['list']) == 0) {
			$this->session->set_flashdata('error', '<h2>Nenhum dado encontrado<h2>');
		}
		$data['sess'] = $this->session->userdata('logged_in');
		$this->load->view('template/header.php', $data);
		$this->load->view('page/lista.php', $data);
		$this->load->view('template/footer.php', $data);
	}
	public function alterar(){
		if ($this->input->post('oper') == 'al') {
			$oper = 0;
		} else { $oper = 1; }
		$data = array('desc' => $this->input->post('desc'), 'oper' => $oper, 'ngbor' => $this->input->post('ngbor'), 'price' => $this->input->post('price'), 'aloc' => $this->input->post('aloc'));
		$res = $this->hsale->alt($this->input->post('cod'), $data);
		if (!$res) {
			$this->session->set_flashdata('error', '<h2>O codigo digitado não existe<h2>');
		}
		header('Location: /');
	}
}
