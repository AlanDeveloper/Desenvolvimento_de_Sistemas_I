<?php
    class HouseSale extends CI_Model {
        public function add($data) {
            $this->db->insert('HouseSale', $data);
		}
		public function del($codigo) {
			$item = $this->search($codigo);
			if (!$item) {
				return False;
			} else {
				$this->db->query('DELETE FROM HouseSale WHERE cod = ' . $codigo);
				return True;
			}
		}
		public function list($filtro){
			$query = 'SELECT * FROM HouseSale';
			if (isset($filtro["ngbor"])) {
				$query = $query.' WHERE `ngbor` LIKE "%'.$filtro["ngbor"].'%" ';
				if (isset($filtro["oper"])) {
					if ($filtro["oper"] == "al") {
						$query = $query."and `oper` = 0";
					}
					if ($filtro["oper"] == "pr") {
						$query = $query."and `oper` = 1";
					}
				}
			} else {
				if (isset($filtro["oper"])) {
					if ($filtro["oper"] == "al") {
						$query = $query." WHERE `oper` = 0";
					}
					if ($filtro["oper"] == "pr") {
						$query = $query." WHERE `oper` = 1";
					}
				}
			}
			if (isset($filtro["aloc"])) {
				$query = $query." ORDER BY `aloc` ".$filtro["aloc"];
			}
			$result = $this->db->query($query);
			$list = array();
            foreach($result->result_array() as $row){
				$house = array($row["cod"], $row["codres"] ,$row["desc"], $row["oper"], $row["ngbor"], $row["price"], $row["aloc"], $row["pic"]);
				array_push($list, $house);
			}
			return $list;
		}
		public function alt($cod, $data){
			$item = $this->search($cod);
			if (!$item) {
				return False;
			} else {
				$this->db->query('UPDATE `HouseSale` SET `desc` = "'.$data['desc'].'", `oper` = '.$data['oper'].', `ngbor` = "'.$data['ngbor'].'", `price` = '.$data['price'].', `aloc` = '.$data['aloc'].' WHERE `cod` = "'.$cod.'"');
				return True;
			}
		}
		public function search($cod){
			$result = $this->db->query('SELECT * FROM HouseSale WHERE `cod` = '.$cod);
			$house = False;
            foreach($result->result_array() as $row){
				$house = array($row["cod"], $row["codres"] ,$row["desc"], $row["oper"], $row["ngbor"], $row["price"], $row["aloc"], $row["pic"]);
			}
			return $house;
		}
    }
?>
