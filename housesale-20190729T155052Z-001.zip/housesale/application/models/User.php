<?php
    class User extends CI_Model {
        public function signin($data) {
            $this->db->insert('user', $data);
		}
		public function login($data){
			$result = $this->db->query('SELECT * FROM user WHERE `login` = "'.$data['username'].'" AND `password` = MD5("'.$data['password'].'")');
			$login = False;
			foreach($result->result_array() as $row){
				$login = True;
				$admin = False;
				if ($row['admin'] == 1) {
					$admin = True;
				}
				return array($login, $admin);
			}
			return array($login);
		}
    }
?>
