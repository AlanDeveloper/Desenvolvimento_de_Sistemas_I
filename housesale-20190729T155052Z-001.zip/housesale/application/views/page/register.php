<form action="/Pages/register" method="post">
	<input type="text" name="username" placeholder="Usuário">
	<input type="text" name="name" placeholder="Nome Completo">
	<input type="password" name="password" placeholder="Senha">
	<input type="submit" value="Enviar">
</form>
