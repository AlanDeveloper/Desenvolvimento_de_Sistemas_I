<?php
	if ($this->session->flashdata('error')) {
		echo $this->session->flashdata('error');
		$this->session->set_flashdata('error', '');
	} else {
		echo	'<table>
				<thead>
					<tr>
						<th>Codigo</th>
						<th>CodRes</th>
						<th>Descrição</th>
						<th>Imagem</th>
						<th>Operação</th>
						<th>Bairro</th>
						<th>Preço</th>
						<th>Alocação</th>
					</tr>
				</thead>';
	}
?>
	<tbody>
		<?php foreach ($list as $item):?>
			<tr>
				<td><?php echo $item[0]?></td>
				<td><?php echo $item[1]?></td>
				<td><?php echo $item[2]?></td>

				<td><img src="../../<?php echo $item[7]?>" alt="Imagem" width="200" height="100"></td>

				<td><?php echo $item[3]?></td>
				<td><?php echo $item[4]?></td>
				<td><?php echo $item[5]?></td>
				<td><?php echo $item[6]?></td>
			</tr>
		<?php endforeach?>
	</tbody>
</table>
