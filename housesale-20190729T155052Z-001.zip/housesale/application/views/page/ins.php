<form action="/Pages/inserir" method="post" enctype="multipart/form-data">
	<textarea name="desc" cols="30" rows="5" placeholder="Descrição"></textarea>
	<select name="oper">
		<option value="al">Aluguel</option>
		<option value="pr">Próprio</option>
	</select>
	<input type="text" name="ngbor" placeholder="Bairro">
	<input type="text" name="codres" placeholder="Número">
	<input type="number" name="price" placeholder="Preço">
	<input type="number" name="aloc" placeholder="alocações">
	<input type="file" name="img" placeholder="Imagem">
	<input type="submit" value="Enviar">
</form>
