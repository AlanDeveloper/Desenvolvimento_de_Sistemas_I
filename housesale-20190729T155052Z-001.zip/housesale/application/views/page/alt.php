<form action="/Pages/alterar" method="post">
	<input type="text" name="cod" placeholder="Codigo">
	<textarea name="desc" cols="30" rows="5" placeholder="Descrição"></textarea>
	<select name="oper">
		<option value="sl">Selecione uma operação</option>
		<option value="al">Aluguel</option>
		<option value="pr">Próprio</option>
	</select>
	<input type="text" name="ngbor" placeholder="Bairro">
	<input type="number" name="price" placeholder="Preço">
	<input type="number" name="aloc" placeholder="alocações">
	<input type="submit" value="Enviar">
</form>