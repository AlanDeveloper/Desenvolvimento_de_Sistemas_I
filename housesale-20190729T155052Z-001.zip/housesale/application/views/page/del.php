<form action="/Pages/deletar" method="post">
	<label for="codDel">Deletar:</label>
	<input type="number" name="codDel">
	<input type="submit" value="Enviar">
</form>