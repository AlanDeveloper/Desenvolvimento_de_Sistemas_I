<?php
	if ($admin) {
		echo '<a href="/ins">Inserir</a>
		<a href="/alt">Alterar</a>
		<a href="/del">Deletar</a>';
	}
?>
<a href="/Pages/pdf">PDF</a>

<form action="/Pages/listar" method="post">
	<label>Bairro:</label>
	<input type="text" name="ngbor">
	<label>Dormitorios:</label>
	<select name="aloc">
		<option value="asc">Cres</option>
		<option value="desc">Decres</option>
	</select>
	<select name="oper">
		<option value="sl">Selecione uma operação</option>
		<option value="al">Aluguel</option>
		<option value="pr">Próprio</option>
	</select>
	<input type="submit" value="Listar">
</form>
<?php
	if ($this->session->flashdata('error')) {
		echo $this->session->flashdata('error');
	}
?>
