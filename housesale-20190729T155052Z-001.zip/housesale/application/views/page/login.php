<a href="register">Registrar</a>
<form action="/Pages/login" method="post">
	<input type="text" name="username" placeholder="Usuário">
	<input type="password" name="password" placeholder="Senha">
	<input type="submit" value="Enviar">
</form>
<?php
	if ($this->session->flashdata('error')) {
		echo $this->session->flashdata('error');
		$this->session->set_flashdata('error', '');
	}
?>
