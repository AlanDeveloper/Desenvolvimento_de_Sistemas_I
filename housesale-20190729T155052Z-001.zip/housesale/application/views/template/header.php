<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title><?php echo $title?></title>
	</head>
	<body>
		<a href="/">Home</a>
		<?php 
			if($sess != null){
				echo '<a href="/Pages/loggout">Sair</a>';
			}
		?>
		<br>
